"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ButtonAction;
(function (ButtonAction) {
    ButtonAction["DismissAndStartGame"] = "DismissAndStartGame";
    ButtonAction["DismissAndExitGame"] = "DismissAndExitGame";
})(ButtonAction = exports.ButtonAction || (exports.ButtonAction = {}));
//# sourceMappingURL=Protocol.js.map